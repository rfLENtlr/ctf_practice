import gmpy2

p = # REDUCTED
q = # REDUCTED
x = # REDUCTED
